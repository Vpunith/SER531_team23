Team 23 - Team members:

Rupika Peela
Punith Sai Vaddi
Sriram Malladi
Prudhvi Sai Reddy Gummireddy
Mogileeswar Reddy Morramreddygari

How to run the project:

Get the events tweet data from twitterAPIAunthentication.py
Run the react app which will let you to choose the event category and location to get the tweet data based on the selection.
SPARQL queries are used for querying the data using Fuseki server.
All the owl files are generated using protege and loaded onto the Fuseki server to run the queries to generate the data using the AWS EC2 instances.